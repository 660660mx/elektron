package uz.elektro.auto;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MainActivity extends Activity {
    private static final String START = "https://elektrolearn-mobile.uzbekistonmet.uz/";
    private static final String HOST = "https://elektrolearn-mobile.uzbekistonmet.uz";
    private static final int FILE_REQ = 1001;
    private static final int[] COUNTS = {9, 6, 4, 2, 1};
    private static final String[] SPEED = {"max", "fast", "normal", "slow"};
    private static final String[] SPEED_LABEL = {"Maks", "Tez", "Normal", "Sekin"};

    // umumiy xotira (barcha oynalar uchun): yodlangan javoblar va hisobot yozuvlari
    static SharedPreferences prefs;
    static final Object LOCK = new Object();
    static long lastAiAt = 0;
    static boolean aiBusy = false;

    private String script = "";
    private ValueCallback<Uri[]> filePathCallback;
    private WebChromeClient chrome;
    private FrameLayout grid;
    private final List<WebView> webs = new ArrayList<WebView>();
    private final List<FrameLayout> cells = new ArrayList<FrameLayout>();
    private int count = 9;
    private int focused = -1;
    private int speedIdx = 1;
    private boolean dry = false;
    private boolean aiOn = true;
    private boolean separate = true;
    private boolean warnedProfiles = false;
    private Button btnCount;
    private Button btnSpeed;
    private Button btnDry;
    private Button btnAi;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("murod", MODE_PRIVATE);
        count = prefs.getInt("count", 9);
        speedIdx = prefs.getInt("speed", 1);
        dry = prefs.getBoolean("dry", false);
        aiOn = prefs.getBoolean("ai", true);
        separate = prefs.getBoolean("separate", true);
        script = readAsset();

        chrome = new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(intent, "Fayl tanlang"), FILE_REQ);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        };

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setBackgroundColor(0xFF0F1B27);
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        scroll.addView(bar, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)));

        bar.addView(mkBtn("▶ Hammasi", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callAll("start()");
            }
        }));
        bar.addView(mkBtn("■ Hammasi", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callAll("stop()");
            }
        }));
        btnSpeed = mkBtn("", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speedIdx = (speedIdx + 1) % SPEED.length;
                prefs.edit().putInt("speed", speedIdx).apply();
                refreshButtons();
                callAll("setSpeed('" + SPEED[speedIdx] + "')");
            }
        });
        bar.addView(btnSpeed);
        btnDry = mkBtn("", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dry = !dry;
                prefs.edit().putBoolean("dry", dry).apply();
                refreshButtons();
                callAll("setDry(" + dry + ")");
            }
        });
        bar.addView(btnDry);
        btnAi = mkBtn("", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                aiOn = !aiOn;
                prefs.edit().putBoolean("ai", aiOn).apply();
                refreshButtons();
                callAll("setAI(" + aiOn + ")");
            }
        });
        bar.addView(btnAi);
        btnCount = mkBtn("", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int next = COUNTS[0];
                for (int i = 0; i < COUNTS.length; i++) {
                    if (COUNTS[i] == count) {
                        next = COUNTS[(i + 1) % COUNTS.length];
                    }
                }
                build(next);
            }
        });
        bar.addView(btnCount);
        btnLogin = mkBtn("", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                separate = !separate;
                prefs.edit().putBoolean("separate", separate).apply();
                build(count);
            }
        });
        bar.addView(btnLogin);
        bar.addView(mkBtn("⟳", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (WebView w : webs) {
                    w.reload();
                }
            }
        }));
        bar.addView(mkBtn("Hisobot", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showReport();
            }
        }));

        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        grid = new FrameLayout(this);
        root.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        grid.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int left, int top, int right, int bottom,
                                       int oldLeft, int oldTop, int oldRight, int oldBottom) {
                if (right - left != oldRight - oldLeft || bottom - top != oldBottom - oldTop) {
                    layoutCells();
                }
            }
        });
        refreshButtons();
        grid.post(new Runnable() {
            @Override
            public void run() {
                build(count);
            }
        });
    }

    private String readAsset() {
        try {
            InputStream in = getAssets().open("elektro-auto.js");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            in.close();
            return out.toString("UTF-8");
        } catch (IOException e) {
            return "";
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button mkBtn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(10), 0, dp(10), 0);
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)));
        return b;
    }

    private void refreshButtons() {
        btnSpeed.setText("Tezlik: " + SPEED_LABEL[speedIdx]);
        btnDry.setText(dry ? "Dry: ON" : "Dry: OFF");
        btnAi.setText(aiOn ? "AI: ON" : "AI: OFF");
        btnCount.setText(count + " ta oyna");
        btnLogin.setText(separate ? "Login: alohida" : "Login: umumiy");
    }

    private void callAll(String js) {
        for (WebView w : webs) {
            w.evaluateJavascript("window.__murodApi&&window.__murodApi." + js, null);
        }
    }

    private void build(int n) {
        for (WebView w : webs) {
            try {
                w.stopLoading();
                w.destroy();
            } catch (Exception e) {
                // e'tiborsiz
            }
        }
        webs.clear();
        cells.clear();
        grid.removeAllViews();
        focused = -1;
        count = n;
        prefs.edit().putInt("count", n).apply();
        refreshButtons();
        for (int i = 0; i < n; i++) {
            final int slot = i + 1;
            FrameLayout cell = new FrameLayout(this);
            cell.setBackgroundColor(0xFF222222);
            WebView w = makeWeb(slot);
            cell.addView(w, new FrameLayout.LayoutParams(100, 100));
            TextView badge = new TextView(this);
            badge.setText(String.valueOf(slot));
            badge.setTextColor(Color.WHITE);
            badge.setBackgroundColor(0xCC16476E);
            badge.setGravity(Gravity.CENTER);
            badge.setTextSize(11);
            FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(dp(28), dp(24));
            bl.gravity = Gravity.TOP | Gravity.RIGHT;
            cell.addView(badge, bl);
            final int idx = i;
            badge.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    focused = (focused == idx) ? -1 : idx;
                    layoutCells();
                }
            });
            grid.addView(cell, new FrameLayout.LayoutParams(100, 100));
            webs.add(w);
            cells.add(cell);
        }
        layoutCells();
        for (WebView w : webs) {
            w.loadUrl(START);
        }
    }

    private WebView makeWeb(final int slot) {
        WebView w = new WebView(this);
        // har bir oyna uchun alohida profil = alohida login (setProfile boshqa hamma narsadan oldin chaqirilishi shart)
        if (separate) {
            boolean ok = false;
            try {
                if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                    String name = "slot" + slot;
                    ProfileStore.getInstance().getOrCreateProfile(name);
                    WebViewCompat.setProfile(w, name);
                    ok = true;
                }
            } catch (Exception e) {
                ok = false;
            }
            if (!ok && !warnedProfiles) {
                warnedProfiles = true;
                Toast.makeText(this, "Bu telefonda WebView alohida loginni qo'llamaydi: hamma oynada umumiy login ishlaydi. (Google'dan Android System WebView'ni yangilang)", Toast.LENGTH_LONG).show();
            }
        }
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        w.setWebChromeClient(chrome);
        final MurodBridge bridge = new MurodBridge(w);
        w.addJavascriptInterface(bridge, "MurodNative");
        w.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                bridge.trusted = (url != null && url.startsWith(HOST));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url != null && url.startsWith(HOST) && !script.isEmpty()) {
                    bridge.trusted = true;
                    String boot = "window.__murod={slot:" + slot + ",tick:250,big:" + (count > 1) + "};";
                    String post = "\nwindow.__murodApi&&(__murodApi.setSpeed('" + SPEED[speedIdx] + "'),__murodApi.setDry(" + dry + "),__murodApi.setAI(" + aiOn + "));";
                    view.evaluateJavascript(boot + script + post, null);
                }
            }
        });
        return w;
    }

    private void layoutCells() {
        int gw = grid.getWidth();
        int gh = grid.getHeight();
        int n = cells.size();
        if (gw <= 0 || gh <= 0 || n == 0) {
            return;
        }
        int cols;
        int rows;
        if (n == 1) {
            cols = 1;
            rows = 1;
        } else if (n == 2) {
            cols = 1;
            rows = 2;
        } else if (n == 4) {
            cols = 2;
            rows = 2;
        } else if (n == 6) {
            cols = 2;
            rows = 3;
        } else {
            cols = 3;
            rows = 3;
        }
        int cw = gw / cols;
        int ch = gh / rows;
        for (int i = 0; i < n; i++) {
            int r = i / cols;
            int c = i % cols;
            int x = c * cw;
            int y = r * ch;
            int w = cw;
            int h = ch;
            if (focused == i) {
                x = 0;
                y = 0;
                w = gw;
                h = gh;
                cells.get(i).bringToFront();
            }
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, h);
            lp.leftMargin = x;
            lp.topMargin = y;
            lp.gravity = Gravity.TOP | Gravity.LEFT;
            cells.get(i).setLayoutParams(lp);
            sizeWeb(webs.get(i), w, h);
        }
    }

    // sahifa har doim ~360 dp kenglikda chiziladi, katak kichik bo'lsa kichraytirib ko'rsatiladi
    private void sizeWeb(WebView web, int w, int h) {
        int base = dp(360);
        float s;
        int vw;
        int vh;
        if (w >= base) {
            s = 1f;
            vw = w;
            vh = h;
        } else {
            s = (float) w / (float) base;
            vw = base;
            vh = Math.round(h / s);
        }
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(vw, vh);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        web.setLayoutParams(lp);
        web.setPivotX(0f);
        web.setPivotY(0f);
        web.setScaleX(s);
        web.setScaleY(s);
    }

    private void showReport() {
        final String text = buildReport();
        new AlertDialog.Builder(this)
                .setTitle("Hisobot")
                .setMessage(text)
                .setPositiveButton("Nusxalash", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null) {
                            cm.setPrimaryClip(ClipData.newPlainText("Hisobot", text));
                            Toast.makeText(MainActivity.this, "Nusxalandi", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Yopish", null)
                .show();
    }

    private String buildReport() {
        StringBuilder sb = new StringBuilder();
        try {
            JSONObject learned;
            JSONArray logs;
            synchronized (LOCK) {
                learned = new JSONObject(prefs.getString("learned", "{}"));
                logs = new JSONArray(prefs.getString("logs", "[]"));
            }
            int aiOk = 0;
            int aiBad = 0;
            StringBuilder unk = new StringBuilder();
            StringBuilder wrong = new StringBuilder();
            StringBuilder ai = new StringBuilder();
            for (int i = 0; i < logs.length(); i++) {
                JSONObject e = logs.getJSONObject(i);
                String t = e.getString("t");
                JSONObject d = new JSONObject(e.getString("d"));
                if (t.equals("unknown")) {
                    unk.append("• ").append(d.optString("q")).append("\n");
                    JSONArray o = d.optJSONArray("opts");
                    if (o != null) {
                        for (int k = 0; k < o.length(); k++) {
                            unk.append("   ").append(k + 1).append(") ").append(o.optString(k)).append("\n");
                        }
                    }
                } else if (t.equals("wrong")) {
                    wrong.append("• ").append(d.optString("q")).append("\n   Bizniki (xato): ")
                            .append(d.optString("ours")).append("\n   TO'G'RI: ").append(d.optString("correct")).append("\n");
                } else if (t.equals("ai")) {
                    boolean ok = d.optBoolean("ok");
                    if (ok) {
                        aiOk++;
                    } else {
                        aiBad++;
                    }
                    ai.append(ok ? "✔ " : "✖ ").append(d.optString("q")).append("\n   AI: ")
                            .append(d.optString("ai")).append("\n   TO'G'RI: ").append(d.optString("correct")).append("\n");
                }
            }
            sb.append("YODLANGAN (bazaga qo'shilgan) javoblar: ").append(learned.length()).append("\n");
            sb.append("AI taxminlari: to'g'ri ").append(aiOk).append(", xato ").append(aiBad).append("\n\n");
            sb.append("=== BAZADA YO'Q BO'LGAN SAVOLLAR ===\n").append(unk.length() == 0 ? "(yo'q)\n" : unk.toString()).append("\n");
            sb.append("=== BAZADAGI XATO JAVOBLAR (tuzatildi) ===\n").append(wrong.length() == 0 ? "(yo'q)\n" : wrong.toString()).append("\n");
            sb.append("=== AI JAVOBLARI ===\n").append(ai.length() == 0 ? "(yo'q)\n" : ai.toString()).append("\n");
            sb.append("=== YODLANGAN JAVOBLAR RO'YXATI ===\n");
            Iterator<String> it = learned.keys();
            while (it.hasNext()) {
                JSONArray a = learned.getJSONArray(it.next());
                sb.append("• ").append(a.optString(0)).append("\n   → ").append(a.optString(1)).append("\n");
            }
        } catch (Exception e) {
            sb.append("Xato: ").append(e.getMessage());
        }
        return sb.toString();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQ && filePathCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && focused >= 0) {
            focused = -1;
            layoutCells();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        for (WebView w : webs) {
            try {
                w.destroy();
            } catch (Exception e) {
                // e'tiborsiz
            }
        }
        super.onDestroy();
    }

    // ---------- JavaScript <-> ilova ko'prigi (faqat sayt sahifasi uchun) ----------
    static class MurodBridge {
        private final WebView web;
        volatile boolean trusted = false;

        MurodBridge(WebView w) {
            web = w;
        }

        @JavascriptInterface
        public String getLearned() {
            if (!trusted) {
                return "[]";
            }
            try {
                synchronized (LOCK) {
                    JSONObject o = new JSONObject(prefs.getString("learned", "{}"));
                    JSONArray arr = new JSONArray();
                    Iterator<String> it = o.keys();
                    while (it.hasNext()) {
                        arr.put(o.getJSONArray(it.next()));
                    }
                    return arr.toString();
                }
            } catch (Exception e) {
                return "[]";
            }
        }

        @JavascriptInterface
        public void putLearned(String key, String entryJson) {
            if (!trusted) {
                return;
            }
            try {
                synchronized (LOCK) {
                    JSONObject o = new JSONObject(prefs.getString("learned", "{}"));
                    o.remove(key);
                    o.put(key, new JSONArray(entryJson));
                    prefs.edit().putString("learned", o.toString()).apply();
                }
            } catch (Exception e) {
                // e'tiborsiz
            }
        }

        @JavascriptInterface
        public void log(String type, String json) {
            if (!trusted) {
                return;
            }
            try {
                synchronized (LOCK) {
                    JSONArray arr = new JSONArray(prefs.getString("logs", "[]"));
                    JSONObject e = new JSONObject();
                    e.put("t", type);
                    e.put("d", json);
                    e.put("ts", System.currentTimeMillis());
                    arr.put(e);
                    JSONArray out = arr;
                    if (arr.length() > 800) {
                        out = new JSONArray();
                        for (int i = arr.length() - 800; i < arr.length(); i++) {
                            out.put(arr.get(i));
                        }
                    }
                    prefs.edit().putString("logs", out.toString()).apply();
                }
            } catch (Exception e) {
                // e'tiborsiz
            }
        }

        // bepul AI (kalitsiz): bir vaqtda faqat bitta so'rov; band bo'lsa false qaytaradi (oyna o'tkazib yuboradi)
        @JavascriptInterface
        public boolean ask(final int id, final String prompt) {
            if (!trusted) {
                return false;
            }
            synchronized (LOCK) {
                long now = System.currentTimeMillis();
                if (aiBusy || now - lastAiAt < 4000) {
                    return false;
                }
                aiBusy = true;
                lastAiAt = now;
            }
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String res = "";
                    try {
                        res = fetchAi(prompt);
                    } catch (Exception e) {
                        res = "";
                    }
                    synchronized (LOCK) {
                        aiBusy = false;
                    }
                    final String js = "window.__murodAI&&window.__murodAI(" + id + "," + JSONObject.quote(res) + ")";
                    web.post(new Runnable() {
                        @Override
                        public void run() {
                            web.evaluateJavascript(js, null);
                        }
                    });
                }
            }).start();
            return true;
        }

        private static String fetchAi(String prompt) throws Exception {
            String[] models = {"openai", "mistral"};
            String enc = URLEncoder.encode(prompt, "UTF-8").replace("+", "%20");
            for (String m : models) {
                HttpURLConnection c = null;
                try {
                    URL u = new URL("https://text.pollinations.ai/" + enc + "?model=" + m);
                    c = (HttpURLConnection) u.openConnection();
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(20000);
                    c.setRequestProperty("User-Agent", "Mozilla/5.0");
                    if (c.getResponseCode() == 200) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = br.readLine()) != null && sb.length() < 4000) {
                            sb.append(line).append("\n");
                        }
                        br.close();
                        String body = sb.toString().trim();
                        if (body.matches("(?s).*[1-9].*")) {
                            return body;
                        }
                    }
                } catch (Exception e) {
                    // keyingi modelga o'tamiz
                } finally {
                    if (c != null) {
                        c.disconnect();
                    }
                }
            }
            return "";
        }
    }
}
